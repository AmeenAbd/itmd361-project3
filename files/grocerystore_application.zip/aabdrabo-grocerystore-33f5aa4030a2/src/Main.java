/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ameen
 */

import java.sql.*;


public class Main {

    /**
     * @param args the command line arguments
     */

    
    public static void main(String[] args) {
        final String url = "jdbc:postgresql://localhost:5432/grocery_store1";
        final String user = "postgres";
        final String password = "Basketball1";//
        //DataScript ds = new DataScript();
        //ds.runScript();
    	try{
                 Connection conn = DriverManager.getConnection(url, user, password);
                 System.out.println("Connected to the PostgreSQL server successfully."); 
    		 	 
    	 }catch (SQLException e) {
                  System.out.println(e.getMessage());
         }
         
        GroceryStoreForm form = new GroceryStoreForm();
        form.setVisible(true);
         
    }
}
